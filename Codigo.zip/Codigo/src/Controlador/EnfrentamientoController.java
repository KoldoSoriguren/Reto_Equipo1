package Controlador;

import Modelo.EnfrentamientoDAO;

public class EnfrentamientoController {
    private EnfrentamientoDAO enfrentamientoDAO;

    public EnfrentamientoController(EnfrentamientoDAO enfrentamientoDAO) {
        this.enfrentamientoDAO = enfrentamientoDAO;
    }
}
