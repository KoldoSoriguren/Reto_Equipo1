package Excepcion;

public class DatoNoValido extends Exception {

        public DatoNoValido(String msg) {

        }
}
