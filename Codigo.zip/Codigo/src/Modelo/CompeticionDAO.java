package Modelo;

public class CompeticionDAO {
}
