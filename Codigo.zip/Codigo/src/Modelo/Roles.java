package Modelo;

public enum Roles {
    DUELISTA, INICIADOR, CENTINELA, CONTROLADOR
}
